#!/usr/bin/env python3 python
# -*- coding: utf-8 -*-
"""
Default config file is set in this file.
"""
import pkg_resources

CONFIGFILE = pkg_resources.resource_filename(__name__, 'config/itspelogger.cfg')
