#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
This module contains the class and functions used for
centralized writing of logs using mqtt.
"""
from datetime import date
import configparser
import paho.mqtt.client as mqtt
from itspelogger.config import CONFIGFILE

# CONFIGFILE is imported from itspelogger.config
class LogWriter:
    """Class for writing logs receviced by mqtt"""
    def __init__(self, config_file=CONFIGFILE):
        """
        Constructor for LogWriter. config file is given as parameter.
        """
        self.config_file = config_file
        self.host, self.logpath, self.topic = self.__get_config()
        # pylint: disable=C0103, W0613
        def on_connect(client, userdata, flags, rc):
            print("Connected with result code "+str(rc))
            client.subscribe(self.topic, 1)
        # pylint: disable=C0103, W0613
        def on_message(client, userdata, msg):
            print(msg.payload)
            self.write_on_file(msg.payload)
        # pylint: disable=C0103, W0613
        def on_disconnect(client, userdata, rc):
            if rc != 0:
                print("Unexpected disconnection.")
            client.disconnect()
        self.client = mqtt.Client()
        self.client.on_disconnect = on_disconnect
        self.client.on_connect = on_connect
        self.client.on_message = on_message
        self.client.connect(self.host, 1883, 60)
    def write_on_file(self, message):
        """
        Writes log to the log file in the configured logpath.
        """
        today = date.today()
        date_string = today.strftime("%Y%m%d")
        filename = "%s/server_%s.log" %(self.logpath, date_string)
        with open(filename, "ab") as filepointer:
            filepointer.write(message + b"\n")
    def __get_config(self):
        """
        reads config file and returns server, logpath, topic values.
        """
        parser = configparser.ConfigParser()
        parser.read(self.config_file)
        server = str(parser.get('Settings', 'MqttServer'))
        logpath = str(parser.get('Settings', 'logpath'))
        topic = str(parser.get('Settings', 'topic'))
        return (server, logpath, topic)
    def loop_forever(self):
        """
        function to start listening for all log messages.
        """
        self.client.loop_forever()

def start_log_writer(config_file=CONFIGFILE):
    """
    Function for starting the Log Writer.
    Holds the Logwriter instance so that the object is not destructed.
    """
    writer = LogWriter(config_file)
    writer.loop_forever()
