#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Logger Class and related functions are defined in this file.
"""
import logging
from logging import StreamHandler
from datetime import date
import time
import socket
from inspect import getframeinfo, stack
import configparser
import paho.mqtt.publish as publish
from itspelogger.config import CONFIGFILE


def get_ip_addresses(family=socket.AF_INET):
    """
    Get all ip address for the family.
    """
    socket_obj = socket.socket(family, socket.SOCK_DGRAM)
    try:
        socket_obj.connect(("8.8.8.8", 80))
        ip_address = socket_obj.getsockname()[0]
        socket_obj.close()
    except OSError:
        hostname = socket.gethostname()
        ip_address = socket.gethostbyname(hostname)
    return ip_address


class MqttHander(StreamHandler):
    """Class derived from StreamHandler for Logging"""
    def __init__(self, host, topic="TIS/Logs", logpath="/var/log/tisLog", console=True):
        """
        Initialize the handler.
        """
        super().__init__()
        self.console = console
        self.host = host
        self.topic = topic
        self.logpath = logpath
        self.publish_status = True

    def emit(self, record):
        """
        Emit a record.
        If a formatter is specified, it is used to format the record.
        The record is then written to the stream with a trailing newline.  If
        exception information is present, it is formatted using
        traceback.print_exception and appended to the stream.  If the stream
        has an 'encoding' attribute, it is used to determine how to do the
        output to the stream.
        """
        msg = self.format(record)
        self.log_publish_message(msg)

    def log_publish_message(self, msg):
        """
        publishes the msg and writes to file it if required.
        """
        if self.console:
            print(msg)
        try:
            publish.single(self.topic, msg, hostname=self.host)
            if not self.publish_status:
                self.write_to_file("[SUCCESS] Connection Established.", self.logpath)
                print("[SUCCESS] Connection Established.")
            self.publish_status = True
        except Exception:
            if self.publish_status:
                self.write_to_file("[ERROR] Error while trying to publish", self.logpath)
                print("[ERROR] Error while trying to publish")
                self.publish_status = False
            self.write_to_file(msg, self.logpath)

    @staticmethod
    def write_to_file(message, logpath="/var/log/tisLog"):
        """
        Writes message to log file in logpath.
        """
        today = date.today()
        date_string = today.strftime("%Y%m%d")
        filename = "%s/local_%s.log" %(logpath, date_string)
        with open(filename, "a") as filepointer:
            filepointer.write(message + "\n")


class Logger:
    """The Logger object for Logging purposes"""
    def __init__(self, module, ip_address=None, console=True, config_file=CONFIGFILE):
        """
        Constructor for Logger
        Args:
            Module(str): Module name for the Logger.
            ip_address(str) : if it is not given the ip address from system is detected automatically.
            console (boolean): boolean which enable the an log output stream to stdout (default: True)
            config_file(str) : file path to configuration file.
        """
        self.module = module
        self.console = console
        self.config_file = config_file
        host, server_type, level, topic, logpath = self.__get_config()
        if ip_address is not None:
            self.ip_address = ip_address
        else:
            ipv4s = get_ip_addresses(socket.AF_INET)
            self.ip_address = ipv4s
        self.logger = logging.getLogger(module)
        for handler in self.logger.handlers:
            self.logger.removeHandler(handler)
        self.handler = MqttHander(host, topic, logpath, console)
        self.handler.setLevel(level)
        self.handler.setFormatter(logging.Formatter(fmt="[%(asctime)s] [%(levelname)s] ["\
                                                     + self.ip_address \
                                                     + '] ['\
                                                     + server_type \
                                                     +'] [%(name)s] %(message)s',
                                                    datefmt='%Y-%m-%d %H:%M:%S'))
        self.logger.addHandler(self.handler)
        self.logger.setLevel(level)

    def __get_config(self):
        """
        Get details from Config file
        """
        parser = configparser.ConfigParser()
        parser.read(self.config_file)
        server = str(parser.get('Settings', 'MqttServer'))
        server_type = str(parser.get('Settings', 'servertype'))
        loglevel = str(parser.get('Settings', 'loglevel'))
        topic = str(parser.get('Settings', 'topic'))
        logpath = str(parser.get('Settings', 'logpath'))
        if loglevel == "NOTSET":
            log_level = logging.NOTSET
        elif loglevel == "DEBUG":
            log_level = logging.DEBUG
        elif loglevel == "INFO":
            log_level = logging.INFO
        elif loglevel == "WARNING":
            log_level = logging.WARNING
        elif loglevel == "ERROR":
            log_level = logging.ERROR
        elif loglevel == "CRITICAL":
            log_level = logging.CRITICAL
        return (server, server_type, log_level, topic, logpath)

    def load_configfile(self, config_file):
        """
        Loads configeration file.
        """
        self.config_file = config_file
        host, server_type, level, topic, logpath = self.__get_config()
        self.logger = logging.getLogger(self.module)
        for handler in self.logger.handlers:
            self.logger.removeHandler(handler)
        self.handler = MqttHander(host, topic, logpath, self.console)
        self.handler.setLevel(level)
        self.handler.setFormatter(logging.Formatter(fmt="[%(asctime)s] [%(levelname)s] ["\
                                                     + self.ip_address \
                                                     + '] ['\
                                                     + server_type \
                                                     +'] [%(name)s] %(message)s',
                                                    datefmt='%Y-%m-%d %H:%M:%S'))
        self.logger.addHandler(self.handler)
        self.logger.setLevel(level)

    def info(self, msg, *args, **kwargs):
        """Log a message with severity 'INFO' on the logger."""
        caller = getframeinfo(stack()[1][0])
        msg = "[%s] [%d] %s" % (caller.filename, caller.lineno, msg)
        self.logger.info(msg, *args, **kwargs)

    def debug(self, msg, *args, **kwargs):
        """Log a message with severity 'DEBUG' on the logger."""
        caller = getframeinfo(stack()[1][0])
        msg = "[%s] [%d] %s" % (caller.filename, caller.lineno, msg)
        self.logger.debug(msg, *args, **kwargs)

    def warning(self, msg, *args, **kwargs):
        """Log a message with severity 'WARNING' on the logger."""
        caller = getframeinfo(stack()[1][0])
        msg = "[%s] [%d] %s" % (caller.filename, caller.lineno, msg)
        self.logger.warning(msg, *args, **kwargs)

    def error(self, msg, *args, **kwargs):
        """Log a message with severity 'ERROR' on the logger."""
        caller = getframeinfo(stack()[1][0])
        msg = "[%s] [%d] %s" % (caller.filename, caller.lineno, msg)
        self.logger.error(msg, *args, **kwargs)
        
    def critical(self, msg, *args, **kwargs):
        """Log a message with severity 'CRITICAL' on the logger."""
        caller = getframeinfo(stack()[1][0])
        msg = "[%s] [%d] %s" % (caller.filename, caller.lineno, msg)
        self.logger.critical(msg, *args, **kwargs)

    def log(self, msg, *args, **kwargs):
        """Log a message with severity 'INFO' on the logger."""
        caller = getframeinfo(stack()[1][0])
        msg = "[%s] [%d] %s" % (caller.filename, caller.lineno, msg)
        self.logger.info(msg, *args, **kwargs)

    def __del__(self):
        """
        Puts delay in Destructor so that mqtt publish is completed.
        """
        prev_time = time.time()
        while True:
            curr_time = time.time()
            if curr_time - prev_time > 0.3:
                break

def publish_formated_message(config_file, message):
    """
    logs the formatted message message.
    """
    parser = configparser.ConfigParser()
    parser.read(config_file)
    server = str(parser.get('Settings', 'MqttServer'))
    topic = str(parser.get('Settings', 'topic'))
    logpath = str(parser.get('Settings', 'logpath'))
    handler = MqttHander(server, topic, logpath)
    handler.log_publish_message(message)
